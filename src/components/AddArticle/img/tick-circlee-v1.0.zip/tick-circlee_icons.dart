// Place fonts/tick-circlee.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: tick-circlee
//      fonts:
//       - asset: fonts/tick-circlee.ttf
import 'package:flutter/widgets.dart';

class Tick_circlee {
  Tick_circlee._();

  static const String _fontFamily = 'tick-circlee';

  static const IconData tick_circle = IconData(0xe900, fontFamily: _fontFamily);
}
